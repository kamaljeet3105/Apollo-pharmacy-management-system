<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>about</title>
	<style type="text/css">

body{
	background-image:linear-gradient(rebeccapurple,white,aqua) ;
}

img{
	height: 400px;
	
}

		.par{
			font-family: sans-serif;
			font-size: 20px;
			
		}
	</style>
</head>
<body>
	<center><img src="m111.jpg"></center>

	<div class="par">

<ul type="bullet">	

<li>
Apollo Pharmacy is a part of Apollo Hospitals - India’s trusted pharmacy.
</li>

<li>
It is India's first and largest branded pharmacy network, with  over 4200 plus  outlets in key locations.
</li>

<li>
accredited with - International Quality  Certification,  Apollo Pharmacy offers  genuine  medicines round-the-clock,  through our 24-hour Pharmacies.
</li>

<li>
 Apollo Pharmacy also  provides customer care any time of the day ! Quality is the cornerstone of our existence.
</li>

<li>
We have gained experience in pharmacy operations management over the last 2 decades and are committed to delivering best service in the industry.
</li>

<li> Apollo Pharmacy is well stocked with medicines, OTC and FMCG products, manned by a team of qualified  and experienced  staff  available to  cater to your every need.
</li>

<li>
Apollopharmacy in has  more than  5000  products  in  various  categories  like  Vitamins ands upplements, Baby Care, Personal Care, Health & Nutrition Foods and OTC.
</li>

<li>In addition to this we have more  than 400  Apollo  Brand  Products in the following  categories  like  vitamins  and supplements, health food, oral care, skincare, personal care, baby care, OTC etc.
</li>

</ul>

</div>
</body>
</html>