<html>
<head>
	<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
			<title></title>
				<style type="text/css">
					body{

							background-image: linear-gradient(10deg,rebeccapurple,rebeccapurple,aqua,aqua,rebeccapurple,rebeccapurple);
						}


					h1{

							font-family:"quicksand";
							font-size:25px;
							color: black;
							text-shadow: 1px 1px rebeccapurple;
							margin: -3px;
							padding: 0px;
							text-align: center;
						}

		
				</style>

</head>
							<body><h1>APOLLO PHARMACY</h1>

</body>
</html>
	
		