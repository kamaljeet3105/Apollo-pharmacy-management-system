<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">

				<style type="text/css">

					.example{

								overflow: hidden;
							}

				</style>


					<frameset rows="8%,5%,85%" >
		 
						<frame name="h1" src="menu1.php" scrolling="no" noresize frameborder="0"/></frame>
						<frame name="h1" src="heading.php" scrolling="no" noresize frameborder="0"/></frame>
						<frame name="mj" src="3.php"   frameborder="0" noresize /></frame>
			
					</frameset>
</head>	
</html>